DROP TABLE IF EXISTS "#__utf8_conversion";
