DELETE FROM `#__scheduler_tasks` WHERE `type` = 'demoTask_r1.sleep';
