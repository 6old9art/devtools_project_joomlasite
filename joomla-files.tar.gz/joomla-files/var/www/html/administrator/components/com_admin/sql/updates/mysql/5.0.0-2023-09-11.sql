UPDATE `#__extensions` SET `enabled` = 1 WHERE `type` = 'plugin' AND `element` = 'schedulerunner' AND `folder` = 'system';
